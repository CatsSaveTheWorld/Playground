from datetime import datetime, time, timedelta
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .device.services.device_service import DeviceService
from .device.services.sequence_executor import SequenceExecutor
from .forms import AutomationTriggerForm
from .models import (
    Automation,
    AutomationCondition,
    AutomationTrigger,
    Device,
    DeviceState,
    Sequence,
    SequenceRun,
    SequenceStep,
    SequenceStepRun,
)
from .scheduler.calculator import calculate_next_run
from .scheduler.service import AutomationService


class AutomationCalculatorTests(TestCase):
    def setUp(self):
        self.sequence = Sequence.objects.create(name="테스트 시퀀스")
        self.automation = Automation.objects.create(
            sequence=self.sequence,
            name="시간 테스트",
        )

    def make_trigger(self, config):
        return AutomationTrigger(
            automation=self.automation,
            trigger_type=AutomationTrigger.TriggerType.TIME,
            config=config,
        )

    def test_daily_trigger_uses_next_local_time(self):
        trigger = self.make_trigger({
            "schedule_type": AutomationTrigger.ScheduleType.DAILY,
            "time": "08:30",
        })
        after = timezone.make_aware(datetime(2026, 8, 1, 9, 0))

        next_run = timezone.localtime(calculate_next_run(trigger, after=after))

        self.assertEqual(next_run.date().isoformat(), "2026-08-02")
        self.assertEqual(next_run.time().replace(tzinfo=None), time(8, 30))

    def test_weekly_trigger_selects_enabled_weekday(self):
        trigger = self.make_trigger({
            "schedule_type": AutomationTrigger.ScheduleType.WEEKLY,
            "time": "07:00",
            "weekdays": [0],
        })
        after = timezone.make_aware(datetime(2026, 8, 1, 9, 0))

        next_run = timezone.localtime(calculate_next_run(trigger, after=after))

        self.assertEqual(next_run.date().isoformat(), "2026-08-03")
        self.assertEqual(next_run.weekday(), 0)

    def test_interval_trigger_advances_from_existing_next_run(self):
        after = timezone.now()
        trigger = self.make_trigger({
            "schedule_type": AutomationTrigger.ScheduleType.INTERVAL,
            "every": 5,
            "unit": "minutes",
        })
        trigger.next_run_at = after - timedelta(minutes=11)

        next_run = calculate_next_run(trigger, after=after)

        self.assertGreater(next_run, after)
        self.assertLessEqual(next_run, after + timedelta(minutes=5))


class AutomationTriggerFormTests(TestCase):
    def test_mqtt_value_is_parsed_as_json_type(self):
        form = AutomationTriggerForm(data={
            "trigger_type": AutomationTrigger.TriggerType.MQTT_EVENT,
            "enabled": "on",
            "event_topic": "zigbee2mqtt/front_door",
            "event_field": "contact",
            "event_operator": "eq",
            "event_value": "true",
        })

        self.assertTrue(form.is_valid(), form.errors)
        self.assertIs(form.cleaned_data["config"]["value"], True)

    def test_hidden_time_fields_do_not_leak_into_mqtt_config(self):
        form = AutomationTriggerForm(data={
            "trigger_type": AutomationTrigger.TriggerType.MQTT_EVENT,
            "enabled": "on",
            "schedule_type": AutomationTrigger.ScheduleType.DAILY,
            "time_of_day": "08:30",
            "event_topic": "zigbee2mqtt/front_door",
            "event_field": "contact",
            "event_operator": "eq",
            "event_value": "false",
        })

        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(
            set(form.cleaned_data["config"]),
            {"topic", "field", "operator", "value"},
        )


class AutomationServiceTests(TestCase):
    def setUp(self):
        self.sequence = Sequence.objects.create(name="예약 시퀀스")
        self.automation = Automation.objects.create(
            sequence=self.sequence,
            name="자동화",
        )

    def test_due_once_trigger_is_enqueued_and_disabled(self):
        now = timezone.now()
        scheduled_for = now - timedelta(seconds=1)
        trigger = AutomationTrigger.objects.create(
            automation=self.automation,
            trigger_type=AutomationTrigger.TriggerType.TIME,
            config={
                "schedule_type": AutomationTrigger.ScheduleType.ONCE,
                "run_at": scheduled_for.isoformat(),
            },
            next_run_at=scheduled_for,
        )

        runs = AutomationService.enqueue_due(now=now)

        self.assertEqual(len(runs), 1)
        run = SequenceRun.objects.get()
        self.assertEqual(run.trigger, SequenceRun.Trigger.AUTOMATION)
        self.assertEqual(run.status, SequenceRun.Status.PENDING)
        trigger.refresh_from_db()
        self.assertFalse(trigger.enabled)
        self.assertIsNone(trigger.next_run_at)

    def test_same_time_trigger_is_not_enqueued_twice(self):
        now = timezone.now()
        scheduled_for = now - timedelta(seconds=1)
        AutomationTrigger.objects.create(
            automation=self.automation,
            trigger_type=AutomationTrigger.TriggerType.TIME,
            config={
                "schedule_type": AutomationTrigger.ScheduleType.INTERVAL,
                "every": 5,
                "unit": "minutes",
            },
            next_run_at=scheduled_for,
        )

        first = AutomationService.enqueue_due(now=now)
        second = AutomationService.enqueue_due(now=now)

        self.assertEqual(len(first), 1)
        self.assertEqual(second, [])
        self.assertEqual(SequenceRun.objects.count(), 1)

    def test_same_mqtt_event_id_is_deduplicated_per_automation(self):
        AutomationTrigger.objects.create(
            automation=self.automation,
            trigger_type=AutomationTrigger.TriggerType.MQTT_EVENT,
            config={
                "topic": "zigbee2mqtt/front_door",
                "field": "contact",
                "operator": "eq",
                "value": False,
            },
        )
        payload = {"event_id": "door-event-1", "contact": False}

        first = AutomationService.process_event(
            "zigbee2mqtt/front_door",
            payload,
        )
        second = AutomationService.process_event(
            "zigbee2mqtt/front_door",
            payload,
        )

        self.assertEqual(len(first), 1)
        self.assertEqual(second, [])
        self.assertEqual(SequenceRun.objects.count(), 1)

    def test_multiple_matching_triggers_only_enqueue_once(self):
        config = {
            "topic": "zigbee2mqtt/front_door",
            "field": "contact",
            "operator": "eq",
            "value": False,
        }
        AutomationTrigger.objects.create(
            automation=self.automation,
            trigger_type=AutomationTrigger.TriggerType.MQTT_EVENT,
            config=config,
        )
        AutomationTrigger.objects.create(
            automation=self.automation,
            trigger_type=AutomationTrigger.TriggerType.MQTT_EVENT,
            config=config,
        )

        runs = AutomationService.process_event(
            "zigbee2mqtt/front_door",
            {"contact": False},
        )

        self.assertEqual(len(runs), 1)
        self.assertEqual(SequenceRun.objects.count(), 1)

    def test_changed_to_uses_previous_device_state(self):
        AutomationTrigger.objects.create(
            automation=self.automation,
            trigger_type=AutomationTrigger.TriggerType.MQTT_EVENT,
            config={
                "topic": "zigbee2mqtt/front_door",
                "field": "contact",
                "operator": "changed_to",
                "value": False,
            },
        )
        AutomationService.update_device_state(
            "zigbee2mqtt/front_door",
            {"contact": True},
        )

        runs = AutomationService.process_event(
            "zigbee2mqtt/front_door",
            {"contact": False},
        )

        self.assertEqual(len(runs), 1)

    def test_time_window_condition_supports_crossing_midnight(self):
        AutomationCondition.objects.create(
            automation=self.automation,
            condition_type=AutomationCondition.ConditionType.TIME_WINDOW,
            config={"start": "22:00", "end": "06:00"},
        )
        now = timezone.make_aware(datetime(2026, 8, 2, 1, 0))

        self.assertTrue(
            AutomationService._conditions_match(self.automation, now)
        )


class SequenceWorkerTests(TestCase):
    def setUp(self):
        self.sequence = Sequence.objects.create(name="쿠키 갱신")
        self.media_server = Device.objects.create(
            device_uid="pi5",
            name="Pi5 미디어 서버",
            device_type="media_server",
            protocol=Device.Protocol.MQTT,
            location="거실",
        )
        self.step = SequenceStep.objects.create(
            sequence=self.sequence,
            order=1,
            device=self.media_server,
            function="ytmusic.refresh_cookie",
        )

    @patch.object(
        DeviceService,
        "execute_step",
        return_value=(True, "갱신 완료"),
    )
    def test_worker_records_successful_step(self, execute):
        sequence_run = SequenceRun.objects.create(
            sequence=self.sequence,
            trigger=SequenceRun.Trigger.MANUAL,
        )

        result = SequenceExecutor.run_next_pending()

        self.assertEqual(result.pk, sequence_run.pk)
        sequence_run.refresh_from_db()
        self.assertEqual(sequence_run.status, SequenceRun.Status.SUCCESS)
        step_run = SequenceStepRun.objects.get(sequence_run=sequence_run)
        self.assertEqual(step_run.status, SequenceStepRun.Status.SUCCESS)
        execute.assert_called_once_with(self.step)

    @patch.object(
        DeviceService,
        "execute_step",
        return_value=(False, "응답 시간 초과"),
    )
    def test_worker_records_failure(self, execute):
        sequence_run = SequenceRun.objects.create(
            sequence=self.sequence,
            trigger=SequenceRun.Trigger.MANUAL,
        )

        SequenceExecutor.run_next_pending()

        sequence_run.refresh_from_db()
        self.assertEqual(sequence_run.status, SequenceRun.Status.FAILED)
        self.assertIn("시간 초과", sequence_run.message)
        self.assertEqual(
            sequence_run.step_runs.get().status,
            SequenceStepRun.Status.FAILED,
        )


class AutomationViewTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="automation-test",
            password="test-password",
        )
        self.client.force_login(self.user)
        self.sequence = Sequence.objects.create(name="화면 테스트")

    def test_toggle_recalculates_time_trigger(self):
        automation = Automation.objects.create(
            sequence=self.sequence,
            name="아침 자동화",
            enabled=False,
        )
        trigger = AutomationTrigger.objects.create(
            automation=automation,
            trigger_type=AutomationTrigger.TriggerType.TIME,
            config={
                "schedule_type": AutomationTrigger.ScheduleType.DAILY,
                "time": "08:30",
            },
            enabled=True,
        )

        response = self.client.post(
            reverse(
                "iotcore:schedule_toggle",
                kwargs={"schedule_id": automation.id},
            )
        )

        self.assertRedirects(response, reverse("iotcore:schedule_list"))
        trigger.refresh_from_db()
        self.assertIsNotNone(trigger.next_run_at)

    def test_manual_sequence_run_is_enqueued(self):
        response = self.client.post(
            reverse(
                "iotcore:sequence_run",
                kwargs={"sequence_id": self.sequence.id},
            )
        )

        self.assertRedirects(response, reverse("iotcore:sequence_list"))
        run = SequenceRun.objects.get()
        self.assertEqual(run.trigger, SequenceRun.Trigger.MANUAL)
        self.assertEqual(run.status, SequenceRun.Status.PENDING)
