import time

from django.core.management.base import BaseCommand
from django.db import close_old_connections

from ...device.services.sequence_executor import SequenceExecutor


class Command(BaseCommand):
    help = "Execute pending IoTCore sequence runs."

    def add_arguments(self, parser):
        parser.add_argument("--once", action="store_true")
        parser.add_argument("--poll-interval", type=float, default=1)

    def handle(self, *args, **options):
        while True:
            sequence_run = None
            try:
                close_old_connections()
                sequence_run = SequenceExecutor.run_next_pending()
                if sequence_run is not None:
                    self.stdout.write(
                        f"실행 #{sequence_run.pk}: "
                        f"{sequence_run.get_status_display()}"
                    )
            except Exception as exc:
                self.stderr.write(
                    f"시퀀스 워커 처리 실패: {type(exc).__name__}: {exc}"
                )
                if options["once"]:
                    raise
            finally:
                close_old_connections()

            if options["once"]:
                return
            if sequence_run is None:
                time.sleep(max(options["poll_interval"], 0.2))
