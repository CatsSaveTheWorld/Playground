class TuyaClient:
    pass